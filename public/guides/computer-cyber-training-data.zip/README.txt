PFSA SYNTHETIC TRAINING DATA - v1.0
All identities, devices and events are fictional. Preserve originals, hash each file, and work on copies. Files are exports, not original media.
